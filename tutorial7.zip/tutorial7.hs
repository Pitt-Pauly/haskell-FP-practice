-- Informatics 1 - Functional Programming 
-- Tutorial 7
--
-- Week 9 - Due: 20/21 Nov.


import LSystem
import Test.QuickCheck

-- Exercise 1

-- 1a. split
split = undefined

-- 1b. join
join = undefined

--1c. testing join, split
prop_join_split = undefined



-- Exercise 2
-- 2a. copy
copy = undefined

-- 2b. pentagon
pentagon = undefined

-- 2c. polygon
polygon = undefined



-- Exercise 3
-- spiral
spiral = undefined


-- Exercise 4
-- optimise
optimise = undefined



-- L-Systems

-- 5. arrowhead
arrowhead = undefined

-- 6. snowflake
snowflake = undefined

-- 7. hilbert
hilbert = undefined

