-- Informatics 1 - Functional Programming 
-- Tutorial 1
--
-- Week 3 - due: 9/10 Oct.

import ChessPieces
import Test.QuickCheck

-- Exercise 1:

pic1 :: Picture
pic1 = undefined

pic2 :: Picture
pic2 = undefined


-- Exercise 2:

fourPieces :: Picture -> Picture
fourPieces pic = undefined

-- Exercise 3: 
-- a)

fourSquares :: Picture
fourSquares = undefined

-- b)
fourKnights :: Picture
fourKnights = undefined

-- c)
-- NOTE: you may have to put some arguments before the '='
piecesOnSquares :: Picture -> Picture
piecesOnSquares = undefined

-- Exercise 4:
-- a)

emptyRow :: Picture
emptyRow = undefined

-- b)

otherEmptyRow :: Picture
otherEmptyRow = undefined

-- c)

middleBoard :: Picture
middleBoard = undefined

-- d)

whiteRow :: Picture
whiteRow = undefined

blackRow :: Picture
blackRow = undefined

-- e)

populatedBoard :: Picture
populatedBoard = undefined

-- Exercise 5:

prop_assoc_above :: Picture -> Picture -> Picture -> Bool
prop_assoc_above p q r = p `above` (q `above` r) == (p `above` q) `above` r

prop_invol_invert :: Picture -> Bool
prop_invol_invert p = invert (invert p) == p

prop_assoc_beside :: Picture -> Picture -> Picture -> Bool
prop_assoc_beside = undefined